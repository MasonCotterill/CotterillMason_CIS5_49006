/* 
 * File:   main.cpp
 * Author: Mason Cotterill
 * Created on September 17, 2017, 3:30 PM
 * Purpose:  Annual Pay
 */
#include <iostream>

using namespace std;

int main()
{
    int payamount, timesperyear, annualpay;
    
    //paid every two weeks
    payamount = 2200
            
    //paid 26 times per years
    timesperyear = 26
            
    //multiply
    annualpay= payamount * timesperyear;
    
    //display
    cout<<"annual wages are $"<<annualpay<<endl;
    
    return 0;
}


/* 
 * File:   main.cpp
 * Author: Mason Cotterill
 * Created on September 17, 2017, 3:00 PM
 * Purpose: To calculate food, tax, and tip
 */
#include <iostream>
using namespace std;
int main()
{
int meal = 88.67;
int tax = 0.0675 * meal; //6.75% tax on the meal
int tip = (tax + meal) * 0.20;  //tip is 20% after adding the tax
int total = meal + tax + tip;  //total bill
cout << "The meal charge is: $" << meal << endl;
cout << "The tax amount is: $" << tax << endl;
cout << "The tip amount is: $" << tip << endl;
cout << "The total bill is: $" << total << endl << endl;
return 0;
}


/* 
 * File:   main.cpp
 * Author: Mason Cotterill
 * Created on September 17, 2017, 12:10 PM
 * Purpose:  Finding Future Value
 */

//System Libraries Here
#include <iostream>
#include <cmath>

using namespace std;

//User Libraries Here


//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float fvPow;  //The Future Value
    float pv;  //The Present Value
    unsigned char i;//Interest rate in % per year
    float fvExpLg;  //Future value calculated in $'s using Exp and 
    unsigned char n;//Number of compounding periods in yrs
    
    //Input or initialize values Here
    pv=100.0f; //$100.00
            i=6;//6%/year
    
    //By the rule of 72 the future value of savings
    n=72/i;
    fvPow=pv*pow(1+i/100.0f,n);
    fvExpLg=pv*exp(n*log(1+i/100.0f));
    
    //Display/Output all pertinent variables
    cout<<"Present Value = $"<<pv<<endl;
    cout<<"The interest rate = "
            <<static_cast<int>(i)<<" %/year"<<endl;
    cout<<"The number of compounding periods = "
            <<static_cast<int>(n)<<" years"<<endl;
    cout<<"The Future using Pow function = $"
            <<static_cast<int>(fvPow)<<" "
            
    //Exit
    return 0;
}


/*
 * File:   main.cpp
 * Author: Mason Cotterill
 * Created on September 5, 2017, 11:37 AM
* Purpose Find percentage of Federal Budget
*/
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //Declare Variables
    float fedBudg;//Federal Budget
    float dodBudg;//Department of Defense or Military Budget
    float nasaBud;//Nasa Budget
    float pctDOD;//Percent DOD budget as a function of Federal
    float pctNASA;//Percent Nasa Budget as a function of Federal
    
    //Initialize Variables 
    fedBudg=3.8e12f;//3.8 Trillion found by Google on line 2017
    dodBudg=608e9f;//608 Billion found by Google on-line 2017
    nasaBud=18.4e9f;//18.4 Billion found by Google on-line 2017
            
    //Process or map the inputs to the outputs
    pctDOD=dodBudg/fedBudg*100;
    pctNASA=nasaBud/fedBudg*100;
    
    //Display/Output all pertinent variables
    cout<<"NASA's 2017 budget = $"<<nasaBud<<endl;
    cout<<"DOD's 2017 budget = $"<<dodBudg<<endl;
    cout<<"Fed's 2017 budget = $"<<fedBudg<<endl;
    cout<<"DOD's percentage of total = "<<pctDOD<<"%"<<endl;
    cout<<"NASA's percentage of total = "<<pctNASA<<"%"<<endl;
    return 0;
}


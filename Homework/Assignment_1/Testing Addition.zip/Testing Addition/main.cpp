/* 
 * File:   main.cpp
 * Author: Mason Cotterill
 * Created on August 29, 2017, 12:01 PM
 *Purpose: Creating a class template
 */

//system Libraries
#include <iostream>  //Input/Output Stream Library
using namespace std;  //Standard Name-space under which system Libraries reside

//User Libraries 

//Global Constants - Not variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here:
int main(int argc, char** argv) {
    //Declare Variables
    short a,b,c;
    //Initialize Variables
    a=20000;
    b=30000;
    //Input Data/Variables
    c=a+b
    //Process or map the inputs to the outputs
    
    //Display/Output all pertinent variables
    ;cout<<a<<" + "<<b<<" = "<<c<<endl;
    //Exit the program
       
    return 0;
}

